const Header = (props) => {
    return ( 
        <p>Bem vindo, {props.username}!</p>
     );
}
 
export default Header;